import hashlib
import secrets
from datetime import datetime, timezone, timedelta
from functools import lru_cache
from zoneinfo import ZoneInfo, available_timezones
from odoo import api, fields, models, _
from odoo.exceptions import UserError


@lru_cache(maxsize=1)
def _controller_tz_selection():
    zones = sorted(available_timezones())
    if "Asia/Ho_Chi_Minh" not in zones:
        zones.insert(0, "Asia/Ho_Chi_Minh")
    return [(tz, tz) for tz in zones]


def _tz_get(self):
    return _controller_tz_selection()


class EntryControlController(models.Model):
    _name = "entry.control.controller"
    _description = "Gatekeeper Controller"
    _order = "last_heartbeat_at desc, id desc"

    controller_uid = fields.Char(string="Controller ID", required=True, index=True, copy=False)
    # Backward-compatible alias for existing controller source/UI names.
    controller_code = fields.Char(string="Controller Code", compute="_compute_controller_code", inverse="_inverse_controller_code", store=True, index=True)
    name = fields.Char(required=True, default="New Controller")
    secret_key = fields.Char(string="Secret Key", required=True, copy=False, groups="t4tek_entry_control.group_entry_control_admin,base.group_system")
    attendance_timezone = fields.Selection(
        _tz_get,
        string="Controller Timezone",
        required=True,
        default=lambda self: self._default_attendance_timezone(),
        help="Business timezone for this Controller. All devices under this Controller use this timezone for device-local days, system-generated 23:59/00:00 boundary logs, and daily attendance cron processing.",
    )
    attendance_timezone_offset = fields.Char(string="Current UTC Offset", compute="_compute_attendance_timezone_offset")

    last_sync_at = fields.Datetime(string="Last Sync At", readonly=True)
    last_heartbeat_at = fields.Datetime(string="Last Heartbeat At", readonly=True)
    status = fields.Selection([
        ("online", "Online"),
        ("offline", "Offline"),
        ("blocked", "Blocked"),
    ], default="offline", required=True, index=True)
    active = fields.Boolean(default=True, index=True)
    note = fields.Text()

    token_hash = fields.Char(copy=False, readonly=True, groups="t4tek_entry_control.group_entry_control_admin,base.group_system")
    token_hint = fields.Char(copy=False, readonly=True, groups="t4tek_entry_control.group_entry_control_admin,base.group_system")
    token_expires_at = fields.Datetime(copy=False, readonly=True, groups="t4tek_entry_control.group_entry_control_admin,base.group_system")
    refresh_token_hash = fields.Char(copy=False, readonly=True, groups="t4tek_entry_control.group_entry_control_admin,base.group_system")
    refresh_token_expires_at = fields.Datetime(copy=False, readonly=True, groups="t4tek_entry_control.group_entry_control_admin,base.group_system")
    last_auth_at = fields.Datetime(readonly=True)
    last_error = fields.Text(readonly=True)

    device_ids = fields.One2many("entry.control.device", "controller_id", string="Devices")
    employee_sync_ids = fields.One2many("entry.control.employee.sync", "controller_id", string="Employees Synced")
    attendance_log_ids = fields.One2many("entry.control.attendance.log", "controller_id", string="Attendance Logs")
    device_count = fields.Integer(compute="_compute_counts")
    employee_sync_count = fields.Integer(compute="_compute_counts")
    attendance_log_count = fields.Integer(compute="_compute_counts")

    company_id = fields.Many2one("res.company", default=lambda self: self.env.company)

    _sql_constraints = [
        ("controller_uid_unique", "unique(controller_uid)", "Controller ID must be unique."),
    ]

    @api.model
    def _default_attendance_timezone(self):
        try:
            return self.env["entry.control.attendance.log"].sudo()._attendance_timezone_name()
        except Exception:
            return "Asia/Ho_Chi_Minh"

    @api.model
    def _validate_attendance_timezone(self, tz_name):
        tz_name = str(tz_name or "").strip() or "Asia/Ho_Chi_Minh"
        try:
            ZoneInfo(tz_name)
        except Exception:
            raise UserError(_("Invalid Controller Timezone '%s'. Please use an IANA timezone name, for example Asia/Ho_Chi_Minh.") % tz_name)
        return tz_name

    def _effective_attendance_timezone(self):
        self.ensure_one()
        return self._validate_attendance_timezone(self.attendance_timezone or self._default_attendance_timezone())

    def _attendance_zoneinfo(self):
        self.ensure_one()
        return ZoneInfo(self._effective_attendance_timezone())

    def _timezone_offset_text(self, at_utc=None):
        self.ensure_one()
        dt = at_utc or fields.Datetime.now()
        if not isinstance(dt, datetime):
            dt = fields.Datetime.to_datetime(dt)
        if not dt:
            dt = fields.Datetime.now()
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        local_dt = dt.astimezone(self._attendance_zoneinfo())
        offset = local_dt.utcoffset() or timedelta(0)
        total_seconds = int(offset.total_seconds())
        sign = "+" if total_seconds >= 0 else "-"
        total_seconds = abs(total_seconds)
        hours, remainder = divmod(total_seconds, 3600)
        minutes = remainder // 60
        return "%s%02d:%02d" % (sign, hours, minutes)

    @api.depends("attendance_timezone")
    def _compute_attendance_timezone_offset(self):
        for rec in self:
            try:
                rec.attendance_timezone_offset = rec._timezone_offset_text()
            except Exception:
                rec.attendance_timezone_offset = "+07:00"


    def init(self):
        """Backfill Controller Timezone for existing Controllers during upgrade."""
        try:
            default_tz = self._default_attendance_timezone()
            self.env.cr.execute(
                """
                UPDATE entry_control_controller
                   SET attendance_timezone = %s
                 WHERE attendance_timezone IS NULL OR attendance_timezone = ''
                """,
                (default_tz,),
            )
        except Exception:
            # Column may not exist yet during early registry/bootstrap on some Odoo builds.
            pass

    @api.depends("controller_uid")
    def _compute_controller_code(self):
        for rec in self:
            rec.controller_code = rec.controller_uid

    def _inverse_controller_code(self):
        for rec in self:
            if rec.controller_code and rec.controller_code != rec.controller_uid:
                rec.controller_uid = rec.controller_code

    @api.depends("device_ids", "employee_sync_ids", "attendance_log_ids")
    def _compute_counts(self):
        Device = self.env["entry.control.device"].sudo()
        EmpSync = self.env["entry.control.employee.sync"].sudo()
        Log = self.env["entry.control.attendance.log"].sudo()
        for rec in self:
            rec.device_count = Device.search_count([("controller_id", "=", rec.id)])
            rec.employee_sync_count = EmpSync.search_count([("controller_id", "=", rec.id)])
            rec.attendance_log_count = Log.search_count([("controller_id", "=", rec.id)])

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("controller_uid"):
                vals["controller_uid"] = str(vals["controller_uid"]).strip().upper()
            if vals.get("attendance_timezone"):
                vals["attendance_timezone"] = self._validate_attendance_timezone(vals.get("attendance_timezone"))
            elif not vals.get("attendance_timezone"):
                vals["attendance_timezone"] = self._default_attendance_timezone()
            if not vals.get("secret_key"):
                vals["secret_key"] = self._new_secret_key()
            if not vals.get("name"):
                vals["name"] = vals.get("controller_uid") or "New Controller"
        return super().create(vals_list)

    def write(self, vals):
        vals = dict(vals or {})
        if vals.get("controller_uid"):
            vals["controller_uid"] = str(vals["controller_uid"]).strip().upper()
        if vals.get("attendance_timezone"):
            vals["attendance_timezone"] = self._validate_attendance_timezone(vals.get("attendance_timezone"))
        return super().write(vals)

    @api.model
    def _hash_token(self, token):
        return hashlib.sha256((token or "").encode("utf-8")).hexdigest()

    @api.model
    def _new_secret_key(self):
        return secrets.token_urlsafe(32)

    @api.model
    def _new_token(self):
        return secrets.token_urlsafe(48)

    def check_access_token(self, token):
        self.ensure_one()
        if not token or not self.token_hash:
            return False
        if self.token_expires_at and self.token_expires_at <= fields.Datetime.now():
            return False
        return self._hash_token(token) == self.token_hash

    def check_refresh_token(self, token):
        self.ensure_one()
        if not token or not self.refresh_token_hash:
            return False
        if self.refresh_token_expires_at and self.refresh_token_expires_at <= fields.Datetime.now():
            return False
        return self._hash_token(token) == self.refresh_token_hash

    def issue_tokens(self):
        self.ensure_one()
        if not self.active or self.status == "blocked":
            raise UserError(_("Controller is inactive or blocked."))
        access_token = self._new_token()
        refresh_token = self._new_token()
        now = fields.Datetime.now()
        access_ttl = int(self.env["ir.config_parameter"].sudo().get_param("entry_control.access_token_ttl_seconds", "3600") or 3600)
        refresh_ttl = int(self.env["ir.config_parameter"].sudo().get_param("entry_control.refresh_token_ttl_seconds", "2592000") or 2592000)
        self.sudo().write({
            "token_hash": self._hash_token(access_token),
            "token_hint": "%s...%s" % (access_token[:8], access_token[-6:]),
            "token_expires_at": now + timedelta(seconds=max(300, access_ttl)),
            "refresh_token_hash": self._hash_token(refresh_token),
            "refresh_token_expires_at": now + timedelta(seconds=max(3600, refresh_ttl)),
            "last_auth_at": now,
            "last_heartbeat_at": now,
            "status": "online",
            "last_error": False,
        })
        return access_token, refresh_token

    def _check_gatekeeper_admin(self):
        if not (self.env.user.has_group("t4tek_entry_control.group_entry_control_admin") or self.env.user.has_group("base.group_system")):
            raise UserError(_("Only Gatekeeper Administrators can perform this action."))

    def action_generate_secret_key(self):
        self._check_gatekeeper_admin()
        for rec in self:
            rec.write({
                "secret_key": rec._new_secret_key(),
                "token_hash": False,
                "refresh_token_hash": False,
                "token_hint": False,
                "token_expires_at": False,
                "refresh_token_expires_at": False,
            })
        # Force form reload so the newly generated value is immediately filled
        # into the Secret Key input. A plain notification can leave the old
        # value visible until the user manually refreshes the form.
        return {"type": "ir.actions.client", "tag": "reload"}

    def action_copy_secret_key(self):
        self.ensure_one()
        self._check_gatekeeper_admin()
        if not self.secret_key:
            raise UserError(_("This controller does not have a secret key."))
        return {
            "type": "ir.actions.client",
            "tag": "t4tek_entry_control.copy_to_clipboard",
            "params": {
                "text": self.secret_key,
                "title": _("Secret Key"),
                "message": _("Secret Key copied to clipboard."),
            },
        }

    def action_block(self):
        self._check_gatekeeper_admin()
        self.write({"status": "blocked", "active": False, "token_hash": False, "refresh_token_hash": False, "last_error": _("Blocked by administrator.")})
        return True

    def action_unblock(self):
        self._check_gatekeeper_admin()
        self.write({"status": "offline", "active": True, "last_error": False})
        return True

    @api.model
    def _heartbeat_timeout_seconds(self):
        """Timeout used by the server-side connection watchdog.

        The Controller actively calls Odoo APIs. When those calls stop for too
        long, Odoo marks the Controller offline and marks its devices unknown.
        """
        ICP = self.env["ir.config_parameter"].sudo()
        value = ICP.get_param("entry_control.controller_heartbeat_timeout_seconds", "300")
        try:
            seconds = int(value)
        except Exception:
            seconds = 300
        return max(60, seconds)

    @api.model
    def cron_check_connection_status(self):
        """Mark stale Controllers offline and their Devices unknown.

        Flow:
        - Controller heartbeat stale  -> Controller = offline
        - Devices under that Controller -> unknown
        - Real device disconnect while Controller is alive is still handled by
          /devices/report and remains Device = offline.
        """
        now = fields.Datetime.now()
        timeout_seconds = self._heartbeat_timeout_seconds()
        threshold = now - timedelta(seconds=timeout_seconds)

        stale_controllers = self.sudo().search([
            ("active", "=", True),
            ("status", "=", "online"),
            "|",
            ("last_heartbeat_at", "=", False),
            ("last_heartbeat_at", "<", threshold),
        ])
        if not stale_controllers:
            return True

        Device = self.env["entry.control.device"].sudo()
        devices_to_unknown = Device.search([
            ("controller_id", "in", stale_controllers.ids),
            ("status", "in", ["online", "offline"]),
        ])

        message = _("Controller heartbeat timeout. No heartbeat received within %s seconds.") % timeout_seconds
        stale_controllers.write({
            "status": "offline",
            "last_error": message,
        })

        if devices_to_unknown:
            devices_to_unknown.write({
                "status": "unknown",
                "last_status_changed_at": now,
            })
        return True
