# Employee ID as device identifier

- `/api/entry_control/v1/employees` now returns `employee_id` as the device user identifier / ZKTeco EnrollNumber, using the employee PIN/barcode field.
- `/employees/sync-status` matches incoming `employee_id` against employee PIN/barcode fields instead of treating it as the numeric Odoo `hr.employee` ID.
- Attendance ingest treats incoming `employee_id` as the device user identifier and matches `hr.employee` by PIN/barcode.
