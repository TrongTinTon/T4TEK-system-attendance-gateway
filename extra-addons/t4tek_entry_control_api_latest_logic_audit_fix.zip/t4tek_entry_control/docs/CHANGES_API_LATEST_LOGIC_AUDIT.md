# API Latest Logic Audit

- Verified Odoo API routes are limited to health, auth token/refresh, hello, employees pull, employee sync status, devices report, and attendance logs push.
- Confirmed there is no `/api/entry_control/v1/user-device-sync/status` route.
- `employee_id` in controller payloads is treated as the device user identifier / ZKTeco EnrollNumber, then matched to `hr.employee` by PIN/barcode fields.
- Refresh token now also rejects blocked/inactive Controllers with HTTP 403 instead of allowing a server-side UserError path.
- Registered backend asset for the Controller Secret Key Copy client action.
